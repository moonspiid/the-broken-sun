// The k8s sandbox's recurring list reads (k8s.ts's header, Room on the node) asked of the API server in-process, not of
// a kubectl spawned for each. A grader reads the nodes and the pods bound to each (K8sSandbox.nodePodRooms), its live
// graders (runningGraders) and the sandbox pods its namespace holds (sandboxPodsHeld) every few seconds, idle or not.
// Measured on makefun-prod (2026-11-12): kubectl decodes every pod whole even for `-o name` (0.54 s of CPU for s18's
// 1.07 MB list, about 0.94 s for one room read), so those reads cost a grader about 0.135 cores idle, 17% of its CPU,
// and 0.47 cores a process while jobs wait for room. The same counts asked as a Table (`Accept:
// application/json;as=Table;g=meta.k8s.io;v=v1`, `includeObject=None`: one row of cells per object, 16 KB for s18) cost
// 1.3-1.6 ms each, with the same `list` verbs the Role and node-read.yaml grant already.
//
// apiListExec is a KubectlExec over the API server: it answers the argv shapes of those reads, `[-n <ns>] get
// pods|nodes [--all-namespaces] [-l <sel>] [--field-selector <sel>] -o name|json`, as kubectl would print them (`pod/<name>`
// lines from the Table's first cell; the API server's own JSON list), and hands every other argv to kubectl. A 403 is
// kubectl's `Error from server (Forbidden): <message>` (what K8sSandbox's refusal path reads); a call its budget or its
// signal cut is kubectl's cut (`error`), never sent again; any other failure (a token or CA that cannot be read, TLS,
// a connection refused, another status, a body that is no list) is that one call sent to kubectl, said once until it
// changes. In a pod (KUBERNETES_SERVICE_HOST and _PORT set, no KUBECONFIG, the service-account token mounted:
// inClusterApiGet) it reads the token and CA from the mount on every call, since a projected token rotates. Node's
// https alone: no client library.

import { existsSync } from 'node:fs';
import { readFile } from 'node:fs/promises';
import { Agent, request } from 'node:https';
import type { LookupFunction } from 'node:net';
import { join } from 'node:path';
import type { KubectlExec, KubectlResult } from './k8s.ts';

/** Where a pod's service-account token, CA and namespace are mounted. */
export const SERVICE_ACCOUNT_DIR = '/var/run/secrets/kubernetes.io/serviceaccount';

/** A list as a Table (meta.k8s.io/v1): one row per object, its cells the printer's columns, the name first. */
export const TABLE_ACCEPT = 'application/json;as=Table;g=meta.k8s.io;v=v1';
export const JSON_ACCEPT = 'application/json';

/** One answer of the API server: its status and its body. */
export interface ApiAnswer {
  status: number;
  body: string;
}

export interface ApiGetOptions {
  accept: string;
  /** No answer within it: an ApiCut. */
  timeoutMs: number;
  /** Aborting it cuts the request: an ApiCut. */
  signal?: AbortSignal;
}

/** A GET of `path` (with its query) on the API server; throws ApiCut when cut, any other Error when it could not be asked. */
export type ApiGet = (path: string, opts: ApiGetOptions) => Promise<ApiAnswer>;

/** A request its budget or its signal cut: kubectl's SIGKILL, said the same way, and not asked again. */
export class ApiCut extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ApiCut';
  }
}

/** The API server and the credentials apiGet reads per call. */
export interface ApiTarget {
  host: string;
  port: number;
  /** The bearer token's file, read on every call. */
  tokenFile: string;
  /** The CA bundle the server's certificate is checked against, read on every call. */
  caFile: string;
  /** How `host` resolves (default the system's); tests point a name at a local server. */
  lookup?: LookupFunction;
}

/**
 * GETs on `target`: the token and CA read fresh each call, over one keep-alive agent per CA (a new CA, a new agent),
 * the request destroyed at its budget or its signal.
 */
export function apiGet(target: ApiTarget): ApiGet {
  let held: { ca: string; agent: Agent } | null = null;
  return async (path, opts) => {
    if (opts.signal?.aborted === true) throw new ApiCut('cut off');
    const [token, ca] = await Promise.all([readFile(target.tokenFile, 'utf8'), readFile(target.caFile, 'utf8')]);
    const bearer = token.trim();
    if (bearer === '') throw new Error(`the service-account token ${target.tokenFile} is empty`);
    if (held === null || held.ca !== ca) {
      held?.agent.destroy();
      held = { ca, agent: new Agent({ keepAlive: true, maxSockets: 4, ca }) };
    }
    const agent = held.agent;
    return new Promise<ApiAnswer>((resolve, reject) => {
      let cut: string | null = null;
      let settled = false;
      const timer = setTimeout(() => stop(`no answer within ${opts.timeoutMs} ms`), opts.timeoutMs);
      timer.unref();
      const onAbort = (): void => stop('cut off');
      const finish = (): boolean => {
        if (settled) return false;
        settled = true;
        clearTimeout(timer);
        opts.signal?.removeEventListener('abort', onAbort);
        return true;
      };
      const fail = (err: Error): void => {
        if (finish()) reject(cut === null ? err : new ApiCut(cut));
      };
      const req = request(
        {
          hostname: target.host,
          port: target.port,
          path,
          method: 'GET',
          agent,
          headers: { accept: opts.accept, authorization: `Bearer ${bearer}` },
          ...(target.lookup === undefined ? {} : { lookup: target.lookup }),
        },
        (res) => {
          const chunks: Buffer[] = [];
          res.on('data', (b: Buffer) => chunks.push(b));
          res.on('error', fail);
          res.on('end', () => {
            if (finish()) resolve({ status: res.statusCode ?? 0, body: Buffer.concat(chunks).toString('utf8') });
          });
          res.on('close', () => {
            if (!res.complete) fail(new Error('the API server closed its answer before its end'));
          });
        },
      );
      function stop(why: string): void {
        cut ??= why;
        req.destroy(new Error(why));
      }
      req.on('error', fail);
      opts.signal?.addEventListener('abort', onAbort, { once: true });
      req.end();
    });
  };
}

/**
 * The API server this process's pod reaches with its own service account, as kubectl's in-cluster config finds it:
 * KUBERNETES_SERVICE_HOST and KUBERNETES_SERVICE_PORT set, no KUBECONFIG (kubectl would read that instead), and the
 * token mounted in `dir`. Null anywhere else (a run from outside the cluster, the e2e rig, k3s from a shell).
 */
export function inClusterApiGet(env: NodeJS.ProcessEnv = process.env, dir: string = SERVICE_ACCOUNT_DIR): ApiGet | null {
  const host = env.KUBERNETES_SERVICE_HOST;
  const port = Number(env.KUBERNETES_SERVICE_PORT);
  if (host === undefined || host === '' || !Number.isInteger(port) || port <= 0 || port > 65_535) return null;
  if (env.KUBECONFIG !== undefined && env.KUBECONFIG !== '') return null;
  const tokenFile = join(dir, 'token');
  if (!existsSync(tokenFile)) return null;
  return apiGet({ host, port, tokenFile, caFile: join(dir, 'ca.crt') });
}

/** One list read apiListExec answers: what it asks and how kubectl would print the answer (null: no list in it). */
export interface ListRead {
  resource: 'pods' | 'nodes';
  path: string;
  accept: string;
  print(body: string): string | null;
}

const SINGULAR = { pods: 'pod', nodes: 'node' } as const;

/** `-o name` from a Table (cells[0] of each row), or from a plain list should the server answer one: `<kind>/<name>` lines. */
function printNames(kind: string, body: string): string | null {
  let doc: { kind?: unknown; rows?: unknown; items?: unknown };
  try {
    doc = JSON.parse(body) as typeof doc;
  } catch {
    return null;
  }
  let names: unknown[];
  if (doc?.kind === 'Table' && Array.isArray(doc.rows)) names = doc.rows.map((r: { cells?: unknown[] } | null) => r?.cells?.[0]);
  else if (Array.isArray(doc?.items)) names = doc.items.map((i: { metadata?: { name?: unknown } } | null) => i?.metadata?.name);
  else return null;
  if (!names.every((n): n is string => typeof n === 'string' && n !== '')) return null;
  return names.map((n) => `${kind}/${n}\n`).join('');
}

/** `-o json`: the API server's list as it sent it, once it is one. */
function printList(body: string): string | null {
  try {
    return Array.isArray((JSON.parse(body) as { items?: unknown })?.items) ? body : null;
  } catch {
    return null;
  }
}

/**
 * The list read an argv asks for, or null for every argv apiListExec leaves to kubectl: `[-n|--namespace <ns>] get
 * pods|nodes` with only `--all-namespaces`/`-A`, `-l`/`--selector`, `--field-selector` (each as one word with `=` or
 * as two) and `-o`/`--output` name or json. Pods need a namespace or every one; nodes take neither.
 */
export function listRead(args: readonly string[]): ListRead | null {
  let i = 0;
  let namespace: string | null = null;
  if (args[0] === '-n' || args[0] === '--namespace') {
    namespace = args[1] ?? null;
    if (namespace === null || namespace === '') return null;
    i = 2;
  }
  if (args[i] !== 'get') return null;
  const resource = args[i + 1];
  if (resource !== 'pods' && resource !== 'nodes') return null;
  let all = false;
  let labels: string | null = null;
  let fields: string | null = null;
  let output: string | null = null;
  for (let j = i + 2; j < args.length; j++) {
    const a = args[j]!;
    const eq = a.indexOf('=');
    const flag = a.startsWith('--') && eq > 0 ? a.slice(0, eq) : a;
    const inline = flag === a ? null : a.slice(eq + 1);
    if (flag === '--all-namespaces' || flag === '-A') {
      if (inline !== null) return null;
      all = true;
      continue;
    }
    const value = inline ?? args[++j];
    if (value === undefined) return null;
    if (flag === '-l' || flag === '--selector') labels = value;
    else if (flag === '--field-selector') fields = value;
    else if (flag === '-o' || flag === '--output') output = value;
    else return null;
  }
  if (output !== 'name' && output !== 'json') return null;
  let base: string;
  if (resource === 'nodes') {
    if (namespace !== null || all) return null;
    base = '/api/v1/nodes';
  } else if (all) base = '/api/v1/pods';
  else if (namespace !== null) base = `/api/v1/namespaces/${encodeURIComponent(namespace)}/pods`;
  else return null;
  const query = new URLSearchParams();
  if (labels !== null && labels !== '') query.set('labelSelector', labels);
  if (fields !== null && fields !== '') query.set('fieldSelector', fields);
  if (output === 'name') query.set('includeObject', 'None');
  const q = query.toString();
  const kind = SINGULAR[resource];
  return {
    resource,
    path: q === '' ? base : `${base}?${q}`,
    accept: output === 'name' ? TABLE_ACCEPT : JSON_ACCEPT,
    print: output === 'name' ? (body) => printNames(kind, body) : printList,
  };
}

/** A Status body's message (a refusal's words), else the body's first line. */
function statusMessage(body: string): string {
  try {
    const m = (JSON.parse(body) as { message?: unknown })?.message;
    if (typeof m === 'string' && m !== '') return m;
  } catch {
    // not a Status
  }
  return body.trim().split('\n')[0]?.slice(0, 300) ?? '';
}

export interface ApiListOptions {
  /** A call's budget when it names none (kubectlExec's: KUBECTL_TIMEOUT_MS). */
  timeoutMs: number;
  /** Where a fall back to kubectl is said, once until its reason changes. */
  warn: (line: string) => void;
}

/** A KubectlExec that answers the list reads listRead knows from `get` and hands everything else to `kubectl` (the header). */
export function apiListExec(get: ApiGet, kubectl: KubectlExec, opts: ApiListOptions): KubectlExec {
  let said: string | null = null;
  return async (args, call = {}) => {
    const read = call.input === undefined ? listRead(args) : null;
    if (read === null) return kubectl(args, call);
    const viaKubectl = (problem: string): Promise<KubectlResult> => {
      if (problem !== said) opts.warn(`k8s sandbox: the API server's list of ${read.resource} could not be read in-process (${problem}): kubectl reads it instead until it can`);
      said = problem;
      return kubectl(args, call);
    };
    let answer: ApiAnswer;
    try {
      answer = await get(read.path, { accept: read.accept, timeoutMs: call.timeoutMs ?? opts.timeoutMs, ...(call.signal === undefined ? {} : { signal: call.signal }) });
    } catch (err) {
      if (err instanceof ApiCut) return { code: null, stdout: '', stderr: '', error: `kubectl get ${read.resource}: ${err.message}` };
      return viaKubectl((err as Error).message);
    }
    if (answer.status === 403) {
      said = null;
      return { code: 1, stdout: '', stderr: `Error from server (Forbidden): ${statusMessage(answer.body)}\n` };
    }
    if (answer.status !== 200) return viaKubectl(`HTTP ${answer.status}: ${statusMessage(answer.body)}`);
    const stdout = read.print(answer.body);
    if (stdout === null) return viaKubectl(`HTTP 200 with no list: ${JSON.stringify(answer.body.slice(0, 120))}`);
    said = null;
    return { code: 0, stdout, stderr: '' };
  };
}
