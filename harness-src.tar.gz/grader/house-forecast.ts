// The house's model entry in a forecast contest: ONE house-paid model call through masq (superbot-router, dialled
// directly, for a model it serves while the pair is set: `router` below) per instance, recorded, then
// replayed by a fixed entry (grader/house-forecast-entry/main.ts) that never calls a model. Modelled on the house
// judge's call (grader/judge-call.ts) and its key (grader/gateway/masq.ts):
//
//   prompt      a system prompt (HOUSE_FORECAST_SYSTEM) and one user message (houseForecastPrompt): the bundle's
//               rules text, the instance's task.json as it is, the output contract, the compact history
//               (compactChartHistory for a Roblox chart contest, its chart's rows; compactPumpHistory for a pump.fun
//               top-5 one, each mark's top rows), then HOUSE_FORECAST_ANSWER_LINE ("answer with the
//               JSON only"). The caller hands each in; nothing here reads a bundle. The prompt is stored as a blob
//               (houseForecastPromptBytes, canonical JSON {system, user}) and the record names its sha256.
//   preflight   houseForecastPreflight: the worst case of HOUSE_FORECAST_ATTEMPTS requests at the largest body any
//               form can send (grader/gateway/policy.ts worstCaseMicroUsd: body bytes / 3 input tokens at the
//               dearest input class, plus max_output_tokens), kept in the record's budget; no dollar figure refuses
//               it: house-paid judging has no spend cap (the owner, 2026-11-11), so max_output_tokens and
//               HOUSE_FORECAST_ATTEMPTS bound the call. A model with no pricing row is held (nothing could price its
//               record or retire its key against a meter): nothing is minted, sent or stored.
//   key         broker.mintJudgeKey (masq.ts judgeKeyRequest): label makefun/<slug>/judge/<phase>/<attempt>, the
//               pinned model alone, no dollar cap, for under 24 h. A dedicated house-forecast label segment needs
//               a masq.ts change; until then the judge segment carries it (a forecast contest has no judge heat to
//               share it with). The key is retired (retireTrialKey) against the call's priced meter as soon as the call ends, a fault included.
//   call        one POST <origin>/v1/chat/completions on the key with MASQ_REVIEW_HEADERS (x-masq-policy off,
//               x-masq-verbatim 1) and x-cosmos-side-spawn (HOUSE_FORECAST_SIDE_SPAWN: a one-shot, so masq places
//               no cache breakpoint of its own). Its form is the judge's: response_format json_object
//               (the superbot family: a non-strict json_schema of the output schema as its grammar takes it,
//               superbotGrammarSchemaOf), or the plain answer for a model that takes no forced tool (judgeFormsOf on
//               the mint's model card). reasoning_effort is the agent's: a flag's, else on the house model
//               (superbot, the default) the house effort, high (houseForecastAgent), named in the record; an agent
//               that names none (a stored record's from before) sends none to the superbot family and nothing to any
//               other model.
//   grammar     superbot's json_schema is compiled to a grammar that refuses a keyword it would ignore, the whole
//               request with it (HTTP 400 "Failed to compile json grammar: JSON Schema at #/properties/top10 is not
//               supported by xgrammar: keyword(s) uniqueItems would be ignored", the dev site, 2026-11-11T04:25Z):
//               that one json_schema leaves out SUPERBOT_GRAMMAR_REFUSED's keywords and says each in its node's
//               description instead, as grader/dialect.ts says a keyword structured outputs do not take. The
//               bundle's parse, which judges the forecast, still refuses what the keyword said (a repeated id).
//               The forced tool's parameters are the schema as it is (masq answered that form 200 on the same
//               schema), and every other model's request is the bytes it always was.
//   budget      superbot pays its reasoning out of max_tokens, and at reasoning_effort max it thinks past the
//               default budget (the dev site's 2026-11-11T04:25Z forecast: cut at 16000): a new forecast on the
//               superbot family at max with no --max-output-tokens of its own gets
//               HOUSE_FORECAST_MAX_EFFORT_OUTPUT_TOKENS (houseForecastAgent), named in the agent, the record and the
//               preflight's worst case alike.
//   dialect     a Claude model is asked on masq's POST /v1/messages in its own dialect (houseForecastWire,
//               judge-call.ts's rule: the key as x-api-key, the body grader/dialect.ts chatToMessages makes of
//               the request, `answer` asking the output schema as structured output where Chat asked
//               json_object), its answer read back as Chat Completions; the attempt says so (`dialect:
//               'messages'`; absent, it went on Chat Completions, as every record from before did), and
//               houseForecastRequestJson rebuilds each attempt's bytes in its own dialect. A request the
//               dialect cannot say (an output schema structured outputs cannot hold) and every superbot call
//               go on Chat Completions byte for byte.
//   router      a key the broker minted at superbot-router (server/superbot-router.ts: routerOfKey(minted), its static
//               key, for a model routerServesModel names while MAKEFUN_SUPERBOT_ROUTER_URL and _KEY are set) is asked at
//               routerOfKey(minted).origin with routerHeaders alone (no x-masq-*, no x-cosmos-side-spawn;
//               x-sbr-speed flex), the same Chat Completions body streamed (the model as routerWireModel names it): on
//               POST /v1/messages as the Messages body server/superbot-router.ts routerMessagesBody makes of it
//               wherever it maps, else on POST /v1/chat/completions (routerWire, the bytes request_sha256 names). The
//               blob stored and read is the document routerAnswerIn assembles from the stream (a Messages one read as
//               the Chat Completions answer it says); a 2xx stream that ended on an error frame, was cut, or holds a
//               frame that is not JSON is an answer that could not be read (`faults`): nothing stored, no attempt.
//               The attempt says `dialect: 'router-messages'` or `'router'`. The forecast's timeout holds the
//               router's head alone: a flex ask may park for the batch lane's 600 s, and the router's own first-byte
//               bound and idle cut end the read (routerDial). The router's card for the
//               model on the key caps the answer (capabilities.max_output_tokens, which the router clamps a request
//               to, cutting and billing it): a card under the agent's max_output_tokens faults before anything is
//               sent. No fresh-key wait: the key is static, so a 401 is a fault at once. The router's one named wait is
//               honoured once a call (clients.md §4.5, CL-2), the forecast's own rule (a judge heat's call, since
//               judge-call.ts's `router`, waits out every one the router names, with no count and no ceiling): a 429,
//               503 or 529 routerResendable allows with a retry-after (routerNamedWaitMs), or a 2xx stream whose
//               in-band error came before any content, names retry_after and does not say retryable false
//               (routerInBandWaitMs), of at most JUDGE_RATE_LIMIT_WAIT_MS, is sent again once, the same bytes, after
//               exactly that wait, no attempt; the second answer is taken whatever it is, and a longer wait is not
//               waited. Nothing else the router answered is sent again. One log line a
//               router call (the options' `log`, default stderr; never a record field) names its answers' served
//               tier (usage.speed), x-sbr-lane and x-sbr-ignored (routerServedWords). Every other key is masq's, byte
//               for byte as above.
//   retry       an answer that gives no valid forecast (unparseable, refused, answered by another model, an HTTP
//               400/413/422, or a forecast the caller's validate refuses) is asked ONCE more, the same messages, as
//               a forced NAMED tool (HOUSE_FORECAST_TOOL, the output schema as its parameters; tool_auto for a model
//               that takes no forced tool, or once masq refused a forced form). Never a third request. An answer cut
//               at finish_reason length ends the call there: the retry would be the same budget, which the answer
//               and its reasoning did not fit, so it is never spent on one (the record says so, and the CLI names a
//               larger --max-output-tokens).
//   fresh key   a 401 on a masq key minted less than MASQ_KEY_WARMUP_MS ago is re-sent, the same bytes, after a wait:
//               no model saw it, so it is no attempt (judge-call.ts's rule).
//   faults      masq (superbot-router on a router key) unreachable, an answer whose body could not be read (on a
//               router key also a 2xx stream routerAnswerIn faults, its message naming the answer's request-id), or
//               any other non-2xx status throws HouseForecastFault, the attempts that completed, the upstream and the
//               retired key on it: no record is made.
//   scope       a 403 that is masq's scope refusal (`this key is not scoped for model <id>`: the minted key's
//               allowedModels, not the call) also pages a `[model-key] ALERT: ` line (server/house-model.ts
//               watchMasqScope), once for every forecast's minted key until a forecast call answers again, never the key;
//               the router's, in the same words, pages its own fix (upstream superbot-router, MAKEFUN_SUPERBOT_ROUTER_KEY).
//
// Every response body is stored as a blob (blobs.put) before it is read; each attempt's usage is priced by
// pricing/price.ts priceUsage at the attempt's own instant, and the record names pricingRev.
//
// The forecast is read from the tool call's arguments, else the message's text past any think block: the JSON it
// holds (answerJsonOf: the whole text, a fenced block or the outermost {...}) re-serialised compactly with a newline,
// or, when it holds none, the text as it came. The caller's validate (the bundle's own vendored scorer parse, wired
// by the CLI: grader/ never imports a bundle) decides whether it is valid; it is recorded either way. The forecast
// kept is the first valid one, else the last answer that held any text from the pinned model.
//
// The record (agent-fun/house-forecast-record/v1, HouseForecastRecord, canonical JSON) is keyed by the sha256 of the
// instance's exact task.json bytes. writeHouseEntry writes it and the forecast into an entry tree built from the
// template (grader/house-forecast-entry/: main.ts, LICENSE, forecasts/, records/), merging with what the tree
// already holds, so a practice instance and the final share one tree. A regrade replays the file; masq is never
// called again for an instance.

import { createHash } from 'node:crypto';
import { copyFileSync, existsSync, mkdirSync, readFileSync, renameSync, rmSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import { fileURLToPath } from 'node:url';
import { z } from 'zod';
import { parseMarkLines, type MarkLineT } from '../collector/pump-forecast/market.ts';
import { chartRowsOf, parseSnapshots, TRENDING_CHART, type ForecastChart } from '../collector/roblox/chart.ts';
import { CassetteUsage, type CassetteUsageT } from '../contracts/agent.ts';
import { ModelId, REASONING_EFFORTS } from '../contracts/competition.ts';
import { IsoDateTime, Sha256Hex } from '../contracts/primitives.ts';
import { priceUsage, pricingRev } from '../pricing/price.ts';
import {
  answerJsonOf,
  MASQ_REVIEW_HEADERS,
  MASQ_TIMEOUT_MS,
  masqAnswerText,
  masqAuthHeaders,
  masqMessagesBody,
  masqSkipsJsonMode,
  masqWire,
  SUPERBOT_UNNAMED_EFFORT,
  withoutThinking,
  type MasqDialect,
  type MasqWire,
} from '../server/entries/ai-review.ts';
import { HOUSE_MODEL, HOUSE_REASONING_EFFORT, watchMasqScope } from '../server/house-model.ts';
import { canonicalJson } from '../sim/canonical.ts';
import { MASQ_KEY_WARMUP_GAP_MS, MASQ_KEY_WARMUP_MS, retireTrialKey, type JudgeKeyPhase, type MasqJudgeKeyBroker, type RetiredTrialKey } from './gateway/masq.ts';
import { worstCaseMicroUsd } from './gateway/policy.ts';
import { isServedModel, MASQ_MODEL_HEADER } from './gateway/upstream.ts';
import { JUDGE_FORCED_FORMS, JUDGE_RATE_LIMIT_WAIT_MS, JUDGE_UNFORCED_FORMS, judgeFormsOf, judgeModelCard, judgeUsageOf, type JudgeBlobs, type JudgeForm, type JudgeForms } from './judge-call.ts';
import {
  ROUTER_DIALECT,
  ROUTER_MESSAGES_DIALECT,
  routerAnswerIn,
  routerDial,
  routerHeaders,
  routerInBandOf,
  routerInBandWaitMs,
  routerNamedWaitMs,
  routerOfKey,
  routerOutputCeiling,
  routerRequestJsonIn,
  routerServedOf,
  routerServedWords,
  routerServesModel,
  routerWire,
  routerWireModel,
  type RouterAnswer,
  type RouterDial,
  type RouterServed,
} from '../server/superbot-router.ts';

/** The record's schema. */
export const HOUSE_FORECAST_RECORD_SCHEMA = 'agent-fun/house-forecast-record/v1';
/**
 * The model a forecast calls when its flags name none: the house model, superbot (server/house-model.ts, the owner's
 * call of 2026-11-09), asked for the house effort (houseForecastAgent). The CLI (scripts/competitions/house-forecast.ts)
 * names its --model always.
 */
export const HOUSE_FORECAST_MODEL = HOUSE_MODEL;
/**
 * The answer's token budget: a flag, this its default. Room for about 900 rows of {universe_id, place, p} at the
 * house's 3 bytes a token; a reasoning_effort's thinking is paid out of it too (the house model at high thought at
 * most 10478 tokens in the live probe of 2026-11-09, on a smaller prompt: server/seeding/llm.ts).
 */
export const HOUSE_FORECAST_MAX_OUTPUT_TOKENS = 16_000;
/**
 * The answer's token budget of a new forecast on the superbot family at reasoning_effort max that names none
 * (houseForecastAgent): its reasoning is paid out of it, and at max it ran past 16,000 on the dev site's forecast of
 * 2026-11-11T04:25Z (25,762 input tokens) and to 32,949 on the house judge's two-text verdicts (540 calls,
 * news-summary-01's judge, whose 49,500 cap is 1.5 times that). 64,000 holds that reasoning 1.5 times over and about
 * 14,500 tokens of answer (about 900 rows of {universe_id, place, p}). On superbot ($0.30 / $1.20 a million input /
 * output tokens) two requests of the dev forecast's prompt at it are a worst case of 2 x (7,729 + 76,800) µUSD =
 * $0.169.
 */
export const HOUSE_FORECAST_MAX_EFFORT_OUTPUT_TOKENS = 64_000;
/** Requests one call may send: the answer, then one format retry. */
export const HOUSE_FORECAST_ATTEMPTS = 2;
/** The forced tool's name, and the json_schema's. */
export const HOUSE_FORECAST_TOOL = 'forecast';
/** x-cosmos-side-spawn's value: a one-shot side spawn, on which masq places no cache breakpoint. */
export const HOUSE_FORECAST_SIDE_SPAWN = 'makefun-house-forecast';
/** The rows of each read the compact history keeps. */
export const HOUSE_FORECAST_HISTORY_TOP_N = 30;
/** The output schema when the caller names none: a JSON object, its shape the output contract's to say. */
export const HOUSE_FORECAST_DEFAULT_SCHEMA: Readonly<Record<string, unknown>> = Object.freeze({ type: 'object' });

/** The system prompt every house forecast call sends. */
export const HOUSE_FORECAST_SYSTEM = [
  "You are make.fun's house forecaster. You enter a forecasting competition as the house's own model entry, scored by exactly the rules every entrant is scored by.",
  'The user message holds the competition rules, the task.json of the instance you forecast, the output contract your forecast must meet, and the history every entrant is given.',
  'Forecast as well as you can from them, then answer with the forecast document alone: one JSON object exactly as the output contract describes, with no prose, no code fence and nothing before or after it.',
].join('\n');

/** The user message's last line. */
export const HOUSE_FORECAST_ANSWER_LINE = 'Answer with the JSON only: the one forecast document the output contract describes, nothing before or after it.';

/** The forced tool's description. */
export const HOUSE_FORECAST_TOOL_DESCRIPTION = 'Submit your forecast: its arguments are the forecast document itself, exactly as the output contract describes.';

/** The entry template: main.ts, LICENSE, forecasts/ and records/. */
export const HOUSE_ENTRY_TEMPLATE_DIR = fileURLToPath(new URL('./house-forecast-entry/', import.meta.url));
/** The template's files, copied into every entry tree as they are. */
export const HOUSE_ENTRY_TEMPLATE_FILES = Object.freeze(['main.ts', 'LICENSE', 'forecasts/README.md', 'records/README.md'] as const);

/** A file name a task.json's `output` may give (the entry's main.ts holds the same rule). */
const OUTPUT_NAME = /^(?!\.{1,2}$)[A-Za-z0-9._-]{1,128}$/;
/** A forced form masq refuses for its model (HTTP 400): Anthropic's "tool_choice: type "tool" and "any" are not supported for this model." */
const FORCED_TOOL_REFUSED = /tool_choice\b.*\bnot supported\b/is;
/** HTTP statuses that refuse this one request: answer-level, so retried, then recorded invalid. */
const ANSWER_LEVEL_STATUSES: ReadonlySet<number> = new Set([400, 413, 422]);

const sha256Hex = (bytes: Uint8Array | string): string => createHash('sha256').update(bytes).digest('hex');
const isoOf = (ms: number): string => new Date(ms).toISOString();
const utf8 = new TextDecoder('utf-8', { fatal: true, ignoreBOM: true });

// ------------------------------------------------------------------ the agent and the input

export type HouseForecastEffort = (typeof REASONING_EFFORTS)[number];

/** The model call's flags: what the record names. */
export interface HouseForecastAgent {
  model: string;
  max_output_tokens: number;
  /**
   * Sent as reasoning_effort when set; unset, the superbot family's off switch (SUPERBOT_UNNAMED_EFFORT, none) on it and
   * nothing otherwise. houseForecastAgent sets it for a new forecast on the house model, so unset is a stored record's
   * agent that named none, rebuilt as it was sent.
   */
  reasoning_effort?: HouseForecastEffort;
}

/**
 * A new forecast's flags with their defaults filled, each checked: HOUSE_FORECAST_MODEL, the answer's budget, and on
 * the house model (exactly HOUSE_MODEL) the house effort (HOUSE_REASONING_EFFORT, high), named in the agent so the
 * record names it; no reasoning_effort on any other model. The budget is HOUSE_FORECAST_MAX_OUTPUT_TOKENS, but on the
 * superbot family at reasoning_effort max HOUSE_FORECAST_MAX_EFFORT_OUTPUT_TOKENS (the header's `budget`); a flag's
 * wins. Never used to rebuild a stored record's request: an agent built from a record names only the effort and the
 * budget the record does (houseForecastRequestBody sends `none` to the superbot family for one that names none, as it
 * was sent).
 */
export function houseForecastAgent(flags: Partial<HouseForecastAgent> = {}): HouseForecastAgent {
  const model = flags.model ?? HOUSE_FORECAST_MODEL;
  if (!ModelId.safeParse(model).success) throw new TypeError(`the house forecast model is an exact model id, got ${JSON.stringify(model)}`);
  const effort = flags.reasoning_effort ?? (model === HOUSE_MODEL ? HOUSE_REASONING_EFFORT : undefined);
  if (effort !== undefined && !(REASONING_EFFORTS as readonly string[]).includes(effort)) throw new TypeError(`reasoning_effort is one of ${REASONING_EFFORTS.join(', ')}, got ${JSON.stringify(effort)}`);
  const max = flags.max_output_tokens ?? (effort === 'max' && masqSkipsJsonMode(model) ? HOUSE_FORECAST_MAX_EFFORT_OUTPUT_TOKENS : HOUSE_FORECAST_MAX_OUTPUT_TOKENS);
  if (!Number.isSafeInteger(max) || max < 1) throw new RangeError(`max_output_tokens is a whole number from 1, got ${max}`);
  return { model, max_output_tokens: max, ...(effort !== undefined ? { reasoning_effort: effort } : {}) };
}

/** What one instance's prompt is built from: the caller reads each (the CLI from the bundle and the instance's input/). */
export interface HouseForecastInput {
  /** The bundle's rules text. */
  rules: string;
  /** The instance's /input/task.json, its exact bytes: their sha256 is the record's key. */
  task: Uint8Array;
  /** The output contract: what the forecast document must be. */
  contract: string;
  /** The history entrants are given, compacted for the prompt (compactChartHistory, compactPumpHistory). */
  history: string;
}

/** A task.json as the house reads it: its key, its text and the output file name it gives. */
export interface HouseForecastTask {
  sha256: string;
  text: string;
  output: string;
}

/** The task's key (sha256 of its exact bytes), text and `output` name; a task that is not UTF-8 JSON naming a plain output file name throws. */
export function houseForecastTaskOf(task: Uint8Array): HouseForecastTask {
  let text: string;
  try {
    text = utf8.decode(task);
  } catch {
    throw new TypeError('task.json is not UTF-8 text');
  }
  let doc: unknown;
  try {
    doc = JSON.parse(text);
  } catch (err) {
    throw new TypeError(`task.json is not JSON: ${err instanceof Error ? err.message : String(err)}`);
  }
  const output = doc !== null && typeof doc === 'object' && !Array.isArray(doc) ? (doc as Record<string, unknown>).output : undefined;
  if (typeof output !== 'string' || !OUTPUT_NAME.test(output)) throw new TypeError(`task.json names no plain output file name (output ${JSON.stringify(output)})`);
  return { sha256: sha256Hex(task), text, output };
}

// ------------------------------------------------------------------ the history

/** A name as one cell of the compact table: control characters (a tab, a newline) become spaces, so a row stays one line of four cells. */
const cellOf = (name: string): string => name.replace(/[\u0000-\u001f\u007f]/g, ' ');

/**
 * A Roblox chart history (history.ndjson: makefun/roblox-chart-snapshot/v1 lines, collector/roblox/chart.ts) as the
 * prompt's compact table: a header line, then each read that holds `chart` (default Top Trending; an Up-and-Coming
 * contest's is Up-and-Coming, its line's up_and_coming rows, the context charts left out), oldest first, as a line
 * `read <at> <source>` and its first `topN` rows as `rank<TAB>universe_id<TAB>name<TAB>playing` (`-` where the read
 * gave no player count). Reads that failed are left out and counted in the header. Every line is checked as the
 * collector checks it; a last line without its newline is read too (a history handed to an entrant is whole).
 *
 * A read costs about 1.5 KB at the top 30, so the preflight's $2 holds a call of 16,000 output tokens on
 * claude-opus-5-5 past about 145 reads: `lastReads` keeps only the latest that many (the header says how many of how
 * many), for a caller whose history is longer.
 */
export function compactChartHistory(historyNdjson: string, topN: number = HOUSE_FORECAST_HISTORY_TOP_N, lastReads?: number, chart: ForecastChart = TRENDING_CHART): string {
  if (!Number.isSafeInteger(topN) || topN < 1) throw new RangeError(`topN is a whole number from 1, got ${topN}`);
  if (lastReads !== undefined && (!Number.isSafeInteger(lastReads) || lastReads < 1)) throw new RangeError(`lastReads is a whole number from 1, got ${lastReads}`);
  const text = historyNdjson === '' || historyNdjson.endsWith('\n') ? historyNdjson : `${historyNdjson}\n`;
  const all = parseSnapshots(text, 'the history');
  const ok = all
    .map((s, i) => ({ s, i, ms: Date.parse(s.at) }))
    .filter(({ s }) => s.ok && chartRowsOf(s, chart) !== null)
    .sort((a, b) => a.ms - b.ms || a.i - b.i);
  const reads = lastReads === undefined ? ok : ok.slice(-lastReads);
  const failed = all.length - ok.length;
  const lines = [
    `${chart.title} chart history: ${reads.length === ok.length ? `${ok.length} reads` : `the last ${reads.length} of ${ok.length} reads`}, oldest first${failed > 0 ? ` (${failed} failed reads left out)` : ''}. ` +
      `Each read is a line "read <time, UTC> <source>", then its top ${topN} rows as rank<TAB>universe_id<TAB>name<TAB>playing (players in the game at the read; - when the read gave none).`,
  ];
  for (const { s } of reads) {
    lines.push('', `read ${s.at} ${s.source}`);
    const rows = [...(chartRowsOf(s, chart) ?? [])].sort((a, b) => a.rank - b.rank).slice(0, topN);
    for (const r of rows) lines.push(`${r.rank}\t${r.universe_id}\t${cellOf(r.name)}\t${r.playing ?? '-'}`);
  }
  return `${lines.join('\n')}\n`;
}

/**
 * The marks a pump.fun top-5 history (compactPumpHistory) shows when the caller names no --last-reads: the latest 12,
 * two hours at the recorder's 10-minute cadence. The rows a mark shows are HOUSE_FORECAST_HISTORY_TOP_N's 30.
 */
export const HOUSE_FORECAST_PUMP_LAST_READS = 12;
/**
 * The most characters (code points) of a coin's symbol a pump.fun row shows: a symbol is its creator's free text,
 * which the mark line does not bound, and the preflight's worst case is sized on it (at most 4 UTF-8 bytes each).
 */
export const HOUSE_FORECAST_PUMP_SYMBOL_CHARS = 16;

/**
 * The marks of a pump.fun top-5 history (history.ndjson: makefun/pumpfun-top5-forecast/mark/v1 lines,
 * collector/pump-forecast/market.ts MarkLine), every line checked as the recorder writes it (a last line without its
 * newline is read too: a history handed to an entrant is whole): the ok ones oldest first, and how many were not ok.
 */
export function pumpHistoryMarksOf(historyNdjson: string): { ok: MarkLineT[]; failed: number } {
  const text = historyNdjson === '' || historyNdjson.endsWith('\n') ? historyNdjson : `${historyNdjson}\n`;
  const all = parseMarkLines(text, 'the history');
  const ok = all
    .map((m, i) => ({ m, i, ms: Date.parse(m.at) }))
    .filter(({ m }) => m.ok)
    .sort((a, b) => a.ms - b.ms || a.i - b.i)
    .map(({ m }) => m);
  return { ok, failed: all.length - ok.length };
}

const LAMPORTS_PER_SOL = 1_000_000_000n;
const LAMPORTS_PER_CENTISOL = 10_000_000n;

/** A cap in lamports (a decimal integer string) as SOL with 2 decimals, rounded down, exactly (never through a float). */
export function solText(lamports: string): string {
  const v = BigInt(lamports);
  return `${v / LAMPORTS_PER_SOL}.${String((v % LAMPORTS_PER_SOL) / LAMPORTS_PER_CENTISOL).padStart(2, '0')}`;
}

/**
 * A pump.fun top-5 history (pumpHistoryMarksOf) as the prompt's compact table: a header line, then each ok mark, oldest
 * first, as a line `mark <at> <eligible> eligible, <graduated> graduated` (the coins created from t0 the read knew, and
 * how many of them had graduated) and its first `topN` rows by rank as
 * `rank<TAB>mint<TAB>symbol<TAB>age_min<TAB>cap_sol<TAB>venue`: the mint whole (an entry names a coin by it), the symbol
 * cut to HOUSE_FORECAST_PUMP_SYMBOL_CHARS, age_min the whole minutes from the coin's creation (its CreateEvent) to the
 * mark, cap_sol its market cap in SOL rounded down to 2 decimals (solText), venue curve, migrating or pool. Marks that
 * failed are left out and counted in the header (the freeze writes ok marks alone, so a frozen history has none).
 * `lastReads` keeps only the latest that many marks (the header says how many of how many); undefined keeps them all.
 * The row's slot, name, quote reserves and flags, the mark's other counts and the rows past `topN` are left out: the
 * history file holds them.
 *
 * A row costs at most about 140 bytes (a 44-character mint, 16 four-byte symbol characters, a 10-million-SOL cap, a
 * 9-character venue), so a mark at the top 30 about 4.2 KB. Measured on that worst case with a 36 KB rules text
 * (tests/unit/house-forecast-pump.test.ts; the preflight's worst case of two requests): the default 12 marks are $0.17
 * on superbot at --reasoning-effort max (64,000 output tokens) and $1.16 on claude-opus-5-5 (16,000); all 66 marks a
 * final's 11 hours hold are $0.22 on superbot and $2.42 on claude-opus-5-5.
 */
export function compactPumpHistory(historyNdjson: string, topN: number = HOUSE_FORECAST_HISTORY_TOP_N, lastReads?: number): string {
  if (!Number.isSafeInteger(topN) || topN < 1) throw new RangeError(`topN is a whole number from 1, got ${topN}`);
  if (lastReads !== undefined && (!Number.isSafeInteger(lastReads) || lastReads < 1)) throw new RangeError(`lastReads is a whole number from 1, got ${lastReads}`);
  const { ok, failed } = pumpHistoryMarksOf(historyNdjson);
  const marks = lastReads === undefined ? ok : ok.slice(-lastReads);
  const lines = [
    `pump.fun market-cap chart history: ${marks.length === ok.length ? `${ok.length} marks` : `the last ${marks.length} of ${ok.length} marks`}, oldest first${failed > 0 ? ` (${failed} failed marks left out)` : ''}. ` +
      `Each mark is a line "mark <time, UTC> <n> eligible, <n> graduated" (the coins created from t0 the read knew, and how many of them had graduated), ` +
      `then its top ${topN} rows by market cap as rank<TAB>mint<TAB>symbol<TAB>age_min<TAB>cap_sol<TAB>venue: age_min the whole minutes from the coin's creation to the mark, ` +
      `cap_sol its market cap in SOL rounded down to 2 decimals, venue curve, migrating or pool; a symbol longer than ${HOUSE_FORECAST_PUMP_SYMBOL_CHARS} characters is cut there.`,
  ];
  for (const m of marks) {
    const at = Date.parse(m.at);
    lines.push('', `mark ${m.at} ${m.counts.eligible} eligible, ${m.counts.graduated} graduated`);
    const rows = [...m.rows].sort((a, b) => a.rank - b.rank).slice(0, topN);
    for (const r of rows) {
      const symbol = Array.from(cellOf(r.symbol)).slice(0, HOUSE_FORECAST_PUMP_SYMBOL_CHARS).join('');
      const age = Math.max(0, Math.floor((at - Date.parse(r.created_at)) / 60_000));
      lines.push(`${r.rank}\t${r.mint}\t${symbol}\t${age}\t${solText(r.market_cap_lamports)}\t${r.venue}`);
    }
  }
  return `${lines.join('\n')}\n`;
}

// ------------------------------------------------------------------ the prompt and the request

/** The two messages one call sends. */
export interface HouseForecastPrompt {
  system: string;
  user: string;
}

/** The prompt of one instance (the header): the rules, task.json, the output contract and the history, under headings, then the answer line. */
export function houseForecastPrompt(input: HouseForecastInput): HouseForecastPrompt {
  const task = houseForecastTaskOf(input.task);
  const user = [
    '## The competition rules',
    '',
    input.rules.trim(),
    '',
    '## task.json',
    '',
    task.text.trim(),
    '',
    '## The output contract',
    '',
    input.contract.trim(),
    '',
    '## The history',
    '',
    input.history.trimEnd(),
    '',
    HOUSE_FORECAST_ANSWER_LINE,
  ].join('\n');
  return { system: HOUSE_FORECAST_SYSTEM, user };
}

/** The prompt as stored: canonical JSON {system, user}, UTF-8. Its sha256 is the record's prompt_sha256. */
export function houseForecastPromptBytes(prompt: HouseForecastPrompt): Uint8Array {
  return new TextEncoder().encode(canonicalJson({ system: prompt.system, user: prompt.user }));
}

/** The forced (or offered) tool: the output schema as its parameters. */
function forecastTool(schema: Readonly<Record<string, unknown>>): Record<string, unknown> {
  return { type: 'function', function: { name: HOUSE_FORECAST_TOOL, description: HOUSE_FORECAST_TOOL_DESCRIPTION, parameters: schema } };
}

/**
 * The keywords superbot's json_schema grammar refuses (the header's `grammar`), each with what its node's description
 * says instead (null: nothing to say, as uniqueItems false asks nothing). Only a keyword masq has refused goes here.
 */
export const SUPERBOT_GRAMMAR_REFUSED: Readonly<Record<string, (value: unknown) => string | null>> = Object.freeze({
  uniqueItems: (v: unknown) => (v === true ? 'Its items are distinct: no value appears twice.' : null),
});

/** The keywords whose value is a map of schemas, a schema, or a list of schemas: where a schema's nodes are. */
const SCHEMA_MAP_KEYS: ReadonlySet<string> = new Set(['properties', 'patternProperties', '$defs', 'definitions', 'dependentSchemas']);
const SCHEMA_ONE_KEYS: ReadonlySet<string> = new Set(['items', 'additionalItems', 'additionalProperties', 'contains', 'not', 'if', 'then', 'else', 'propertyNames', 'unevaluatedItems', 'unevaluatedProperties']);
const SCHEMA_LIST_KEYS: ReadonlySet<string> = new Set(['items', 'prefixItems', 'anyOf', 'allOf', 'oneOf']);
/** The deepest node superbotGrammarSchemaOf walks: an output schema is a few levels deep. */
const GRAMMAR_SCHEMA_DEPTH = 64;

function grammarNode(node: unknown, depth: number): unknown {
  if (node === null || typeof node !== 'object' || Array.isArray(node) || depth > GRAMMAR_SCHEMA_DEPTH) return node;
  const out: Record<string, unknown> = {};
  const notes: string[] = [];
  let changed = false;
  for (const [k, v] of Object.entries(node as Record<string, unknown>)) {
    const refused = Object.hasOwn(SUPERBOT_GRAMMAR_REFUSED, k) ? SUPERBOT_GRAMMAR_REFUSED[k] : undefined;
    if (refused !== undefined) {
      const note = refused(v);
      if (note !== null) notes.push(note);
      changed = true;
      continue;
    }
    let kept: unknown = v;
    if (SCHEMA_LIST_KEYS.has(k) && Array.isArray(v)) {
      const list = v.map((s) => grammarNode(s, depth + 1));
      if (list.some((s, i) => s !== v[i])) kept = list;
    } else if (SCHEMA_MAP_KEYS.has(k) && v !== null && typeof v === 'object' && !Array.isArray(v)) {
      const entries = Object.entries(v as Record<string, unknown>).map(([n, s]) => [n, grammarNode(s, depth + 1), s] as const);
      if (entries.some(([, t, s]) => t !== s)) kept = Object.fromEntries(entries.map(([n, t]) => [n, t]));
    } else if (SCHEMA_ONE_KEYS.has(k)) kept = grammarNode(v, depth + 1);
    if (kept !== v) changed = true;
    out[k] = kept;
  }
  if (!changed) return node;
  if (notes.length > 0) {
    const note = notes.join(' ');
    // In the description's own place when the node has one, else last.
    out.description = typeof out.description === 'string' && out.description !== '' ? `${out.description} ${note}` : note;
  }
  return out;
}

/**
 * `schema` as superbot's json_schema grammar takes it (the header's `grammar`): every node's SUPERBOT_GRAMMAR_REFUSED
 * keyword left out and said in its description instead, every other key in its place. A schema that holds none is
 * returned as it is, the same object, so its request is the bytes it always was.
 */
export function superbotGrammarSchemaOf(schema: Readonly<Record<string, unknown>>): Readonly<Record<string, unknown>> {
  return grammarNode(schema, 0) as Readonly<Record<string, unknown>>;
}

/**
 * The chat-completions body of one request (deterministic: the same input gives the same bytes): the two messages,
 * max_tokens, reasoning_effort when the agent names one (SUPERBOT_UNNAMED_EFFORT, none, on the superbot family
 * otherwise, so a stored record that named none rebuilds byte for byte), then by form (judge-call.ts's forms): `answer`
 * asks for a JSON object (the superbot family: a non-strict json_schema of `schema` as its grammar takes it,
 * superbotGrammarSchemaOf), `tool` forces the
 * named forecast tool, `answer_plain` adds nothing, `tool_auto` offers the tool with tool_choice auto. `dialect`
 * `messages` is the body the Messages request is made of (the header's `dialect`): its `answer` asks `schema` of every
 * model.
 */
export function houseForecastRequestBody(
  agent: HouseForecastAgent,
  prompt: HouseForecastPrompt,
  form: JudgeForm,
  schema: Readonly<Record<string, unknown>> = HOUSE_FORECAST_DEFAULT_SCHEMA,
  dialect: MasqDialect = 'chat',
): Record<string, unknown> {
  const superbot = masqSkipsJsonMode(agent.model);
  const effort = agent.reasoning_effort ?? (superbot ? SUPERBOT_UNNAMED_EFFORT : undefined);
  const base: Record<string, unknown> = {
    model: agent.model,
    messages: [
      { role: 'system', content: prompt.system },
      { role: 'user', content: prompt.user },
    ],
    max_tokens: agent.max_output_tokens,
    ...(effort !== undefined ? { reasoning_effort: effort } : {}),
  };
  if (form === 'tool') return { ...base, tools: [forecastTool(schema)], tool_choice: { type: 'function', function: { name: HOUSE_FORECAST_TOOL } } };
  if (form === 'tool_auto') return { ...base, tools: [forecastTool(schema)], tool_choice: 'auto' };
  if (form === 'answer_plain') return base;
  if (superbot) return { ...base, response_format: { type: 'json_schema', json_schema: { name: HOUSE_FORECAST_TOOL, strict: false, schema: superbotGrammarSchemaOf(schema) } } };
  return { ...base, response_format: dialect === 'messages' ? { type: 'json_schema', json_schema: { name: HOUSE_FORECAST_TOOL, strict: false, schema } } : { type: 'json_object' } };
}

/** The request one attempt sends masq (the header's `dialect`): on Messages when the dialect can say it, else houseForecastRequestBody's on Chat Completions. */
export function houseForecastWire(agent: HouseForecastAgent, prompt: HouseForecastPrompt, form: JudgeForm, schema: Readonly<Record<string, unknown>> = HOUSE_FORECAST_DEFAULT_SCHEMA): MasqWire {
  return masqWire(houseForecastRequestBody(agent, prompt, form, schema), houseForecastRequestBody(agent, prompt, form, schema, 'messages'));
}

/** The dialect an attempt went in: masq's two (MasqDialect), or superbot-router's own two (ROUTER_DIALECT on Chat Completions, ROUTER_MESSAGES_DIALECT on Messages: the header's `router`). */
export type HouseForecastDialect = MasqDialect | typeof ROUTER_DIALECT | typeof ROUTER_MESSAGES_DIALECT;

/** One request as sent: its dialect, its path on the upstream, and its body text (the bytes request_sha256 names). */
export interface HouseForecastWire {
  dialect: HouseForecastDialect;
  path: string;
  body: string;
}

/** The request one attempt sends superbot-router (the header's `router`): houseForecastRequestBody's Chat Completions body, streamed, on Messages where it maps (routerWire). */
export function houseForecastRouterWire(agent: HouseForecastAgent, prompt: HouseForecastPrompt, form: JudgeForm, schema: Readonly<Record<string, unknown>> = HOUSE_FORECAST_DEFAULT_SCHEMA): HouseForecastWire {
  return routerWire(houseForecastRequestBody(agent, prompt, form, schema));
}

/**
 * The bytes a recorded attempt sent, rebuilt in its own dialect (its `dialect`, absent `chat`): what its request_sha256
 * names. Null when the request cannot be said on Messages.
 */
export function houseForecastRequestJson(
  dialect: HouseForecastDialect,
  agent: HouseForecastAgent,
  prompt: HouseForecastPrompt,
  form: JudgeForm,
  schema: Readonly<Record<string, unknown>> = HOUSE_FORECAST_DEFAULT_SCHEMA,
): string | null {
  if (dialect === 'chat') return JSON.stringify(houseForecastRequestBody(agent, prompt, form, schema));
  if (dialect === ROUTER_DIALECT || dialect === ROUTER_MESSAGES_DIALECT) return routerRequestJsonIn(dialect, houseForecastRequestBody(agent, prompt, form, schema));
  return masqMessagesBody(houseForecastRequestBody(agent, prompt, form, schema, 'messages'));
}

// ------------------------------------------------------------------ the preflight

/** Why a call does not start: its model is unpriced. No dollar figure holds one (the header's `preflight`). */
export interface HouseForecastHold {
  kind: 'unpriced';
  /** What holds it, in an admin's words. */
  why: string;
}

/** The preflight's figures (µUSD), recorded; none of them is weighed against a cap. */
export interface HouseForecastBudget {
  /** HOUSE_FORECAST_ATTEMPTS: the most requests the call sends. */
  requests: number;
  /** The largest body any form sends, bytes. */
  bodyBytes: number;
  /** ceil(bodyBytes / 3): the input tokens the worst case bills. */
  inputTokens: number;
  /** worstCaseMicroUsd of the largest body and max_output_tokens; null for an unpriced model. */
  requestMicroUsd: bigint | null;
  /** requests × requestMicroUsd; null for an unpriced model. */
  worstMicroUsd: bigint | null;
}

const ALL_FORMS: readonly JudgeForm[] = [...JUDGE_FORCED_FORMS, ...JUDGE_UNFORCED_FORMS];

/**
 * The call's worst case (the header): HOUSE_FORECAST_ATTEMPTS requests, each at the largest body any form sends on any
 * route the model may take (masq's dialects, and superbot-router's streamed body for a model routerServesModel names:
 * the route is known only once the key is minted). The hold when the model is unpriced; null otherwise, whatever the
 * worst case comes to.
 */
export function houseForecastPreflight(input: {
  agent: HouseForecastAgent;
  prompt: HouseForecastPrompt;
  schema?: Readonly<Record<string, unknown>>;
  /** The pricing instant, ISO 8601. */
  at: string;
}): { budget: HouseForecastBudget; hold: HouseForecastHold | null } {
  // Every dialect's body, whichever is larger (a superbot request has Chat's, and the router's when it may go there).
  const routed = routerServesModel(input.agent.model);
  const bodyBytes = Math.max(
    ...ALL_FORMS.flatMap((form) => [
      Buffer.byteLength(JSON.stringify(houseForecastRequestBody(input.agent, input.prompt, form, input.schema))),
      Buffer.byteLength(houseForecastWire(input.agent, input.prompt, form, input.schema).body),
      ...(routed ? [Buffer.byteLength(houseForecastRouterWire(input.agent, input.prompt, form, input.schema).body)] : []),
    ]),
  );
  const budget: HouseForecastBudget = { requests: HOUSE_FORECAST_ATTEMPTS, bodyBytes, inputTokens: 0, requestMicroUsd: null, worstMicroUsd: null };
  let one: bigint;
  try {
    const worst = worstCaseMicroUsd({ model: input.agent.model, at: input.at, body_bytes: bodyBytes, output_tokens: input.agent.max_output_tokens });
    budget.inputTokens = worst.input_estimate;
    one = worst.micro_usd;
  } catch (err) {
    return { budget, hold: { kind: 'unpriced', why: `the model ${input.agent.model} cannot be priced (${err instanceof Error ? err.message : String(err)}), so neither the record nor the key's retirement could be metered` } };
  }
  budget.requestMicroUsd = one;
  budget.worstMicroUsd = one * BigInt(HOUSE_FORECAST_ATTEMPTS);
  return { budget, hold: null };
}

// ------------------------------------------------------------------ the record

const MicroUsd = z.string().regex(/^(0|[1-9][0-9]*)$/, 'expected µUSD as a decimal string');

/** One request of the call. */
export const HouseForecastAttempt = z.strictObject({
  form: z.enum(['answer', 'tool', 'answer_plain', 'tool_auto']),
  /** `messages`: sent on masq's Messages route (the header's `dialect`); `router` / `router-messages`: sent to superbot-router, streamed, on Chat Completions / Messages (the header's `router`); absent, on masq's Chat Completions. */
  dialect: z.union([z.literal('messages'), z.literal(ROUTER_DIALECT), z.literal(ROUTER_MESSAGES_DIALECT)]).optional(),
  /** sha256 of the exact body bytes sent (houseForecastRequestJson in the attempt's dialect). */
  request_sha256: Sha256Hex,
  request_bytes: z.int().min(0),
  /** When it was sent: its pricing instant. */
  at: IsoDateTime,
  status: z.int(),
  /** sha256 of the response body: the blob it was stored as, before it was read. */
  response_body_sha256: Sha256Hex,
  /** The completion's `model`, else x-masq-model (a model masq swapped in by its header first); null when neither names one. */
  model_answered: z.string().nullable(),
  finish_reason: z.string().nullable(),
  usage: CassetteUsage.nullable(),
  /** Its price (priceUsage at `at`); '0' for a refused status with no usage; null when a 2xx answer carried no usage it could be priced by. */
  micro_usd: MicroUsd.nullable(),
  /** Why it gave no valid forecast; null for the one that did. */
  invalid: z.string().nullable(),
});
export type HouseForecastAttemptT = z.infer<typeof HouseForecastAttempt>;

/** The forecast an answer held, as the record names it. */
export const HouseForecastKept = z.strictObject({
  /** The attempt it came from, from 1. */
  attempt: z.int().min(1).max(HOUSE_FORECAST_ATTEMPTS),
  sha256: Sha256Hex,
  bytes: z.int().min(0),
  /** Whether the caller's validate (the bundle's own scorer parse) took it. */
  valid: z.boolean(),
  /** Why it did not; null when valid. */
  why: z.string().nullable(),
});

export const HouseForecastRecord = z
  .strictObject({
    schema: z.literal(HOUSE_FORECAST_RECORD_SCHEMA),
    competition: z.string().min(1),
    phase: z.enum(['dev', 'final', 'local']),
    /** sha256 of the instance's exact task.json bytes: the record's key and the forecast's file name. */
    task_sha256: Sha256Hex,
    /** The file name task.json's `output` gives: where the entry writes the forecast. */
    output: z.string().regex(OUTPUT_NAME),
    model: z.string().min(1),
    max_output_tokens: z.int().min(1),
    reasoning_effort: z.enum(REASONING_EFFORTS).nullable(),
    /** sha256 of houseForecastPromptBytes: the prompt blob. */
    prompt_sha256: Sha256Hex,
    rules_sha256: Sha256Hex,
    contract_sha256: Sha256Hex,
    history_sha256: Sha256Hex,
    /** The output schema the answer and tool forms were sent with (canonical JSON), by sha256. */
    schema_sha256: Sha256Hex,
    /**
     * The preflight's figures, µUSD as decimal strings. cap_micro_usd is a record's from before house-paid judging lost
     * its spend cap (the owner, 2026-11-11): the per-call cap it was held to then; a new record names none.
     */
    budget: z.strictObject({
      requests: z.int().min(1),
      body_bytes: z.int().min(0),
      input_tokens: z.int().min(0),
      request_micro_usd: MicroUsd,
      worst_micro_usd: MicroUsd,
      cap_micro_usd: MicroUsd.optional(),
    }),
    /**
     * The key the call was sent on, never its secret. daily_limit_usd is a record's from before, its key's masq cap then;
     * a new record's key has none.
     */
    key: z.strictObject({ id: z.string().min(1), label: z.string().min(1), daily_limit_usd: z.number().optional(), expires_at: IsoDateTime }),
    attempts: z.array(HouseForecastAttempt).min(1).max(HOUSE_FORECAST_ATTEMPTS),
    /** The response blob the forecast came from (the last attempt's when none held one). */
    response_sha256: Sha256Hex,
    /** Every attempt's usage summed; null when none carried any. */
    usage: CassetteUsage.nullable(),
    /** Every attempt's price summed, µUSD: the meter the key was retired against. */
    cost_micro_usd: MicroUsd,
    /** pricing/price.ts pricingRev: the rows every figure was priced under. */
    pricing_rev: Sha256Hex,
    /** masq's settled spend on the key once retired; null when the retirement failed (retire_error says why). */
    masq_spend: z.strictObject({ micro_usd: MicroUsd, settled: z.boolean(), mismatch: z.boolean(), flags: z.array(z.string()) }).nullable(),
    retire_error: z.string().nullable(),
    forecast: HouseForecastKept.nullable(),
    created_at: IsoDateTime,
  })
  .refine((r) => r.forecast === null || r.forecast.attempt <= r.attempts.length, { message: "the forecast's attempt is one of the record's", path: ['forecast', 'attempt'] });
export type HouseForecastRecordT = z.infer<typeof HouseForecastRecord>;

/** A record as written: its canonical JSON and a newline, checked first. */
export function houseForecastRecordBytes(record: HouseForecastRecordT): Uint8Array {
  return new TextEncoder().encode(`${canonicalJson(HouseForecastRecord.parse(record))}\n`);
}

// ------------------------------------------------------------------ the call

/** What the caller's validate answers: the bundle's own scorer parse, run on the forecast's bytes. */
export type HouseForecastValidation = { ok: true } | { ok: false; why: string };
export type HouseForecastValidate = (bytes: Uint8Array) => HouseForecastValidation;

/** The upstream a house forecast call goes to: masq, or superbot-router dialled directly (the header's `router`). */
export type HouseForecastUpstream = 'masq' | 'superbot-router';

/**
 * masq (superbot-router on a router key) unreachable, an answer whose body could not be read, a status that is no
 * answer, a router stream that faulted, or a router key whose card cannot hold the budget: the platform's failure. No
 * record is made.
 */
export class HouseForecastFault extends Error {
  /** The status the upstream answered; null when no answer was read. */
  readonly status: number | null;
  /** The attempts that completed before the fault (each priced, its body stored). */
  readonly attempts: readonly HouseForecastAttemptT[];
  /** The upstream that faulted (default masq). */
  readonly upstream: HouseForecastUpstream;
  /** What an operator does about it when a run again will not (a router key's output ceiling); null otherwise. */
  readonly fix: string | null;
  /** The key retired against their meter; null until retired, or when the retirement failed too. */
  retired: RetiredTrialKey | null = null;
  constructor(message: string, status: number | null, attempts: readonly HouseForecastAttemptT[], options?: { cause?: unknown; upstream?: HouseForecastUpstream; fix?: string }) {
    super(message, options?.cause === undefined ? undefined : { cause: options.cause });
    this.name = 'HouseForecastFault';
    this.status = status;
    this.attempts = attempts;
    this.upstream = options?.upstream ?? 'masq';
    this.fix = options?.fix ?? null;
  }
}

export interface HouseForecastCallOptions {
  /** Where the key is minted: masq's judge-key broker, or server/superbot-router.ts judgeKeyBroker's (a key it mints at the router is a RouterJudgeKey: routerOfKey). */
  broker: MasqJudgeKeyBroker;
  /** The competition's slug: the key's label. */
  slug: string;
  /** The instance's phase: the key's label. */
  phase: JudgeKeyPhase;
  /** The key's nth try for the phase, from 1 (default 1): a re-run after a fault mints anew under the next. */
  attempt?: number;
  /** The model flags (houseForecastAgent fills the defaults). */
  agent?: Partial<HouseForecastAgent>;
  input: HouseForecastInput;
  /** The forecast's JSON schema: the forced tool's parameters and the superbot family's json_schema (default a JSON object). */
  outputSchema?: Readonly<Record<string, unknown>>;
  /** The bundle's own scorer parse on the forecast's bytes. A validate that throws is read as refusing it. */
  validate: HouseForecastValidate;
  /** Where the prompt and every response body are stored (server/blobstore.ts BlobStore fits). */
  blobs: JudgeBlobs;
  fetch?: typeof fetch;
  /** Each request's bound, ms (default MASQ_TIMEOUT_MS); on a router key its head's alone (the header's `router`). */
  timeoutMs?: number;
  /** The clock (ms), default Date.now. */
  now?: () => number;
  /** The wait before a fresh key's 401, or the router's one named wait (the header's `router`), is re-sent, default a timer; it rejects when `signal` aborts. */
  sleep?: (ms: number, signal: AbortSignal | undefined) => Promise<void>;
  signal?: AbortSignal;
  /** Where a scope refusal's `[model-key] ALERT: ` page goes (default console.error: the alert forwarder reads stderr). */
  page?: (line: string) => void;
  /** Where a router call's one served line goes (the header's `router`), default console.warn (a report, not an error: server/ops/errors.ts counts every console.error as a server error). */
  log?: (line: string) => void;
}

/**
 * The scope page's words for a house forecast key masq refuses its model (the header's `scope`, server/house-model.ts
 * watchMasqScope): what fails, the key, and the episode every forecast's minted key shares, so one refused mint
 * configuration pages once, not once a forecast.
 */
const FORECAST_SCOPE_FAILS = 'the house forecast (each call faults with HTTP 403, so no forecast contest gets its house entry)';
const FORECAST_SCOPE_KEYS = "the house forecast key minted per call, makefun/<slug>/judge/<phase>/<attempt>: its allowedModels are grader/gateway/masq.ts judgeKeyRequest's";
/** The key a router call's scope page names: superbot-router's one static key (the header's `router`). */
const FORECAST_ROUTER_SCOPE_KEYS = 'MAKEFUN_SUPERBOT_ROUTER_KEY';
const FORECAST_SCOPE_EPISODE = 'minted house forecast keys';

export type HouseForecastOutcome =
  | { held: HouseForecastHold; budget: HouseForecastBudget }
  | {
      held: null;
      record: HouseForecastRecordT;
      /** The forecast's bytes (record.forecast names them); null when no answer held any. */
      forecast: Uint8Array | null;
      prompt: HouseForecastPrompt;
      budget: HouseForecastBudget;
      /** The key retired against the meter; null when the retirement failed (record.retire_error). */
      retired: RetiredTrialKey | null;
    };

/** A forecast an answer held. */
interface Candidate {
  attempt: number;
  bytes: Uint8Array;
  valid: boolean;
  why: string | null;
}

const isRecord = (v: unknown): v is Record<string, unknown> => v !== null && typeof v === 'object' && !Array.isArray(v);

// The completion masq answers with, or the one superbot-router's stream assembles to, read leniently: only what a
// forecast needs.
const ChatCompletion = z.object({
  model: z.string().optional(),
  choices: z
    .array(
      z.object({
        message: z
          .object({
            content: z.union([z.string(), z.null()]).optional(),
            refusal: z.union([z.string(), z.null()]).optional(),
            tool_calls: z.array(z.object({ function: z.object({ name: z.string().optional(), arguments: z.string().optional() }).optional() })).nullable().optional(),
          })
          .optional(),
        finish_reason: z.string().nullable().optional(),
      }),
    )
    .optional(),
  usage: z.unknown().optional(),
  error: z.unknown().optional(),
});

/** The price of `usage` at `at`: on the model that answered when it has a pricing row, else on the model asked for. */
function priceOf(asked: string, answered: string | null, at: string, usage: CassetteUsageT): bigint | null {
  for (const model of answered !== null && answered !== asked ? [answered, asked] : [asked]) {
    const priced = priceUsage({ model, at, format: 'tokens', usage });
    if (priced.microUsd !== null) return priced.microUsd;
  }
  return null;
}

function sumUsage(all: readonly (CassetteUsageT | null)[]): CassetteUsageT | null {
  let sum: CassetteUsageT | null = null;
  for (const u of all) {
    if (u === null) continue;
    sum ??= { input: 0, output: 0, cache_read: 0, cache_write_5m: 0, cache_write_1h: 0, reasoning: 0 };
    for (const k of Object.keys(sum) as (keyof CassetteUsageT)[]) sum[k] += u[k];
  }
  return sum;
}

/** The meter of a call's attempts, µUSD: every priced attempt summed. */
export function houseForecastMeterMicroUsd(attempts: readonly HouseForecastAttemptT[]): bigint {
  let sum = 0n;
  for (const t of attempts) if (t.micro_usd !== null) sum += BigInt(t.micro_usd);
  return sum;
}

/** The forecast an answer's text holds (the header): its JSON re-serialised with a newline, else the text as it came; null when it holds nothing. */
export function houseForecastBytesOf(content: string): Uint8Array | null {
  const read = answerJsonOf(content);
  if (read.ok) return new TextEncoder().encode(`${JSON.stringify(read.json)}\n`);
  const text = withoutThinking(content);
  return text === '' ? null : new TextEncoder().encode(text);
}

const sleepFor = (ms: number, signal: AbortSignal | undefined): Promise<void> => delay(ms, undefined, signal === undefined ? {} : { signal });

interface SendOptions {
  origin: string;
  apiKey: string;
  agent: HouseForecastAgent;
  prompt: HouseForecastPrompt;
  schema: Readonly<Record<string, unknown>>;
  forms: JudgeForms;
  validate: HouseForecastValidate;
  blobs: JudgeBlobs;
  fetch: typeof fetch;
  timeoutMs: number;
  now: () => number;
  sleep: (ms: number, signal: AbortSignal | undefined) => Promise<void>;
  signal: AbortSignal | undefined;
  keyMintedAt: number;
  /** Whether the key is superbot-router's (the header's `router`): its wire, its answer, no fresh-key wait. */
  router: boolean;
  /** Each attempt as it completes: the call's meter, a fault's included. */
  attempts: HouseForecastAttemptT[];
  /** On a router key, what each answer read said of how it was served (routerServedOf), a refused or dropped one's included. */
  served: RouterServed[];
  page: ((line: string) => void) | undefined;
}

/** The call's requests (the header): the answer, then at most one retry. Throws HouseForecastFault on a platform fault. */
async function sendHouseForecast(o: SendOptions): Promise<{ taken: Candidate | null; last: Candidate | null }> {
  const quote = (text: string, max: number): string => (o.apiKey === '' ? text : text.split(o.apiKey).join('[the house key]')).slice(0, max);
  const attempts = o.attempts;
  const upstream: HouseForecastUpstream = o.router ? 'superbot-router' : 'masq';
  const fault = (message: string, status: number | null, cause?: unknown): HouseForecastFault => new HouseForecastFault(message, status, attempts, { upstream, ...(cause === undefined ? {} : { cause }) });
  // The model the upstream is asked for, and answers as: on the router, its own id for it.
  const wireModel = o.router ? routerWireModel(o.agent.model) : o.agent.model;
  let forms: JudgeForms = o.forms;
  let taken: Candidate | null = null;
  let last: Candidate | null = null;
  let waited = 0;
  let gap = MASQ_KEY_WARMUP_GAP_MS;
  // The router's one named wait, honoured once a call (the header's `router`).
  let routerResent = false;
  // An answer cut at the budget ends the call: the retry would be the same budget (the header's `retry`).
  let cut = false;
  for (let i = 0; i < HOUSE_FORECAST_ATTEMPTS && taken === null && !cut; i++) {
    const form = forms[i === 0 ? 0 : 1];
    // Sent as this string, which fetch writes as its UTF-8 bytes: the bytes request_sha256 names.
    const masqWireOf = o.router ? null : houseForecastWire(o.agent, o.prompt, form, o.schema);
    const wire: HouseForecastWire = masqWireOf ?? houseForecastRouterWire(o.agent, o.prompt, form, o.schema);
    const routerDialect = wire.dialect === ROUTER_DIALECT || wire.dialect === ROUTER_MESSAGES_DIALECT ? wire.dialect : null;
    const json = wire.body;
    const endpoint = new URL(wire.path, o.origin).href;
    // The router reads its Bearer key alone and ignores masq's headers, so none is sent (the header's `router`).
    const headers =
      masqWireOf === null
        ? routerHeaders(o.apiKey, routerDialect ?? ROUTER_DIALECT)
        : { ...masqAuthHeaders(masqWireOf.dialect, o.apiKey), 'content-type': 'application/json', accept: 'application/json', ...MASQ_REVIEW_HEADERS, 'x-cosmos-side-spawn': HOUSE_FORECAST_SIDE_SPAWN };
    let at: string;
    let res: Response;
    let raw: Uint8Array;
    // A router answer is the document assembled from its stream (the header's `router`); null on masq.
    let routed: RouterAnswer | null = null;
    for (;;) {
      at = isoOf(o.now());
      // On the router the call's bound holds its head alone, then the router's own (the header's `router`); on masq the whole call.
      const dial: RouterDial | null = o.router ? routerDial({ headMs: o.timeoutMs, ...(o.signal === undefined ? {} : { signal: o.signal }) }) : null;
      const timeout = dial === null ? AbortSignal.timeout(o.timeoutMs) : null;
      const signal = dial !== null ? dial.signal : o.signal === undefined ? timeout! : AbortSignal.any([o.signal, timeout!]);
      try {
        res = await o.fetch(endpoint, { method: 'POST', headers, body: json, signal });
      } catch (err) {
        dial?.done();
        throw fault(`${upstream} could not be reached: ${quote(err instanceof Error ? err.message : String(err), 300)}`, null, err);
      }
      try {
        raw = dial === null ? new Uint8Array(await res.arrayBuffer()) : await dial.read(res);
      } catch (err) {
        throw fault(`${upstream}'s answer (${res.status}) could not be read: ${quote(err instanceof Error ? err.message : String(err), 300)}`, null, err);
      } finally {
        dial?.done();
      }
      if (routerDialect !== null) {
        routed = routerAnswerIn(routerDialect, raw);
        o.served.push(routerServedOf(res.status, res.headers, routed.text));
        // The router's one named wait (the header's `router`): a refused status's retry-after, or an in-band error's
        // retry_after before any content; once a call, whole, at most JUDGE_RATE_LIMIT_WAIT_MS. Nothing else is sent again,
        // and the router's key is static, never fresh: its 401 is a fault at once.
        const band = res.ok && routed.fault !== null ? routerInBandOf(routerDialect, routed.text) : null;
        const named = band !== null ? routerInBandWaitMs(band) : res.ok ? null : routerNamedWaitMs(res.status, res.headers, o.now());
        if (named === null || routerResent || named > JUDGE_RATE_LIMIT_WAIT_MS) break;
        routerResent = true;
        const why = band !== null ? `superbot-router shed it in band (${band.shed ?? 'an error frame'})` : `superbot-router refused it (${res.status})`;
        try {
          await o.sleep(named, o.signal);
        } catch (err) {
          if (o.signal?.aborted) throw new HouseForecastFault(`the house forecast call was aborted while ${why}`, null, attempts, { upstream, cause: err });
          throw err;
        }
        if (o.signal?.aborted) throw new HouseForecastFault(`the house forecast call was aborted while ${why}`, null, attempts, { upstream });
        continue;
      }
      if (res.status !== 401) break;
      const age = Math.max(o.now() - o.keyMintedAt, waited);
      if (age >= MASQ_KEY_WARMUP_MS) break;
      // masq does not know the fresh key yet: no model saw the request, so it is sent again, not recorded.
      const wait = Math.min(gap, MASQ_KEY_WARMUP_MS - age);
      try {
        await o.sleep(wait, o.signal);
      } catch (err) {
        if (o.signal?.aborted) throw new HouseForecastFault('the house forecast call was aborted while masq did not yet know the fresh key', null, attempts, { cause: err });
        throw err;
      }
      if (o.signal?.aborted) throw new HouseForecastFault('the house forecast call was aborted while masq did not yet know the fresh key', null, attempts);
      waited += wait;
      gap *= 2;
    }
    // A router answer is the document assembled from its stream (the header's `router`): that text is what is stored
    // and read, a Messages one as a masq Messages answer is.
    if (res.ok && routed !== null && routed.fault !== null) {
      // A 2xx stream that is no answer (an in-band shed, a cut stream, a frame that is not JSON) is an answer that could not
      // be read: nothing stored, no attempt, not metered (the header's `faults`).
      const requestId = res.headers.get('request-id');
      throw fault(`superbot-router's answer (${res.status}) could not be read: ${quote(routed.fault, 300)}${requestId === null ? '' : ` (request-id ${quote(requestId, 100)})`}`, null);
    }
    const body = routed === null ? raw : new TextEncoder().encode(routed.text);
    // Stored before it is read: the record names the blob, and a forecast is never taken from a body the house does not keep.
    const stored = await o.blobs.put(body);
    const text = routed === null ? Buffer.from(raw.buffer, raw.byteOffset, raw.byteLength).toString('utf8') : routed.text;
    // A key the upstream refuses its model pages once an episode (the header's `scope`); an answer re-arms it.
    watchMasqScope({
      url: endpoint,
      model: wireModel,
      key: o.apiKey,
      ...(o.router ? { upstream: 'superbot-router' as const } : { episode: FORECAST_SCOPE_EPISODE }),
      status: res.status,
      body: text,
      fails: FORECAST_SCOPE_FAILS,
      keyNames: o.router ? FORECAST_ROUTER_SCOPE_KEYS : FORECAST_SCOPE_KEYS,
      ...(o.page ? { page: o.page } : {}),
    });
    let doc: z.infer<typeof ChatCompletion> | null = null;
    try {
      // A Messages answer is read as the Chat Completions answer it says (the header's `dialect`).
      const parsed = ChatCompletion.safeParse(JSON.parse(wire.dialect === 'messages' || wire.dialect === ROUTER_MESSAGES_DIALECT ? masqAnswerText('messages', text) : text));
      if (parsed.success) doc = parsed.data;
    } catch {
      doc = null;
    }
    // The router names the model in its answer alone; x-masq-model is masq's.
    const header = o.router ? null : res.headers.get(MASQ_MODEL_HEADER);
    // A model masq swapped in (x-masq-model) is the one that answered and billed, whatever the body names.
    const swapped = header !== null && !isServedModel(o.agent.model, header) ? header : null;
    const answered = swapped ?? (doc?.model !== undefined && doc.model.trim() !== '' ? doc.model : header);
    const usage = judgeUsageOf(doc?.usage);
    const priced = usage === null ? null : priceOf(o.agent.model, answered, at, usage);
    const attempt: HouseForecastAttemptT = {
      form,
      ...(wire.dialect === 'chat' ? {} : { dialect: wire.dialect }),
      request_sha256: sha256Hex(json),
      request_bytes: Buffer.byteLength(json),
      at,
      status: res.status,
      response_body_sha256: stored.sha256,
      model_answered: answered,
      finish_reason: doc?.choices?.[0]?.finish_reason ?? null,
      usage,
      micro_usd: priced !== null ? priced.toString() : res.ok ? null : '0',
      invalid: null,
    };
    if (!res.ok && !ANSWER_LEVEL_STATUSES.has(res.status)) {
      attempts.push(attempt);
      throw fault(`${upstream} answered ${res.status}: ${quote(text, 300)}`, res.status);
    }
    attempt.invalid = res.ok ? null : quote(`${upstream} refused the request (${res.status}): ${text}`, 300);
    // masq refuses a forced tool to a model that always thinks: the retry offers it instead.
    if (res.status === 400 && (form === 'answer' || form === 'tool') && FORCED_TOOL_REFUSED.test(text)) forms = [form, 'tool_auto'];
    if (attempt.invalid === null) {
      const choice = doc?.choices?.[0];
      const message = choice?.message;
      const call = message?.tool_calls?.find((t) => t.function?.name === HOUSE_FORECAST_TOOL)?.function?.arguments;
      const content = call ?? message?.content ?? '';
      if (doc === null) attempt.invalid = quote(`${upstream} answered ${res.status} with a body that is not a chat completion: ${text}`, 300);
      else if (doc.error !== undefined) attempt.invalid = quote(`${upstream} answered an error: ${JSON.stringify(doc.error)}`, 300);
      else if (swapped !== null) attempt.invalid = `masq answered with ${swapped} (${MASQ_MODEL_HEADER}), not ${o.agent.model}, the house's pinned model`;
      else if (!isServedModel(wireModel, doc.model ?? '')) attempt.invalid = `${upstream}'s answer ${doc.model === undefined || doc.model.trim() === '' ? 'names no model' : `was served by ${doc.model}`}, not ${wireModel}, the house's pinned model`;
      else if (choice?.finish_reason === 'length') {
        attempt.invalid = `the answer was cut off at the ${o.agent.max_output_tokens}-token budget (finish_reason length): a cut answer is never read as a forecast, and is not asked again at the same budget`;
        cut = true;
      }
      else if (typeof message?.refusal === 'string' && message.refusal.trim() !== '') attempt.invalid = quote(`the model refused: ${message.refusal}`, 300);
      else if (choice?.finish_reason === 'content_filter' || choice?.finish_reason === 'refusal') attempt.invalid = `the model refused (finish_reason ${choice?.finish_reason})`;
      else {
        const bytes = houseForecastBytesOf(content);
        if (bytes === null) {
          attempt.invalid = `the answer holds no content${call === undefined && (form === 'tool' || form === 'tool_auto') ? ' and no forecast tool call' : ''} (finish_reason ${choice?.finish_reason ?? 'none'})`;
        } else {
          let verdict: HouseForecastValidation;
          try {
            verdict = o.validate(bytes);
          } catch (err) {
            verdict = { ok: false, why: `the validator threw: ${err instanceof Error ? err.message : String(err)}` };
          }
          const why = verdict.ok ? null : quote(verdict.why, 600);
          last = { attempt: i + 1, bytes, valid: verdict.ok, why };
          if (verdict.ok) taken = last;
          else attempt.invalid = `the forecast does not meet the output contract: ${why}`;
        }
      }
    }
    attempts.push(attempt);
  }
  return { taken, last };
}

/**
 * One instance's house forecast (the header): the preflight, the key, the call, the key's retirement, the record.
 * A hold answers `held` and nothing is minted, sent or stored. Throws HouseForecastFault on a platform fault (the key
 * retired first), the broker's own error when the mint fails, and a TypeError on a task.json that is not UTF-8 JSON
 * naming a plain output file name.
 */
export async function callHouseForecast(opts: HouseForecastCallOptions): Promise<HouseForecastOutcome> {
  const now = opts.now ?? Date.now;
  const agent = houseForecastAgent(opts.agent);
  const task = houseForecastTaskOf(opts.input.task);
  const prompt = houseForecastPrompt(opts.input);
  const schema = opts.outputSchema ?? HOUSE_FORECAST_DEFAULT_SCHEMA;
  const pre = houseForecastPreflight({ agent, prompt, schema, at: isoOf(now()) });
  if (pre.hold !== null) return { held: pre.hold, budget: pre.budget };
  const budget = pre.budget;

  const promptBlob = await opts.blobs.put(houseForecastPromptBytes(prompt));
  const signalOpt = opts.signal !== undefined ? { signal: opts.signal } : {};
  // Minted with no dollar cap, as every judge key is (masq.ts judgeKeyRequest).
  const minted = await opts.broker.mintJudgeKey({ slug: opts.slug, phase: opts.phase, attempt: opts.attempt ?? 1, model: agent.model }, { now: now(), ...signalOpt });
  const mintedAt = now();
  // A router key (the header's `router`) is asked at its own origin, and lists the model under the router's id for it.
  const router = routerOfKey(minted);
  const card = minted.models === undefined ? null : judgeModelCard(minted.models, router === null ? agent.model : routerWireModel(agent.model));
  const forms = judgeFormsOf(card);

  const attempts: HouseForecastAttemptT[] = [];
  const served: RouterServed[] = [];
  // A router call's one served line (the header's `router`), once it is done, a fault's included; never a record field.
  const logServed = (): void => {
    if (router === null || served.length === 0) return;
    (opts.log ?? ((line: string) => console.warn(line)))(`[house-forecast] ${minted.label} on superbot-router (${routerWireModel(agent.model)}): ${routerServedWords(served)}`);
  };
  let sent: { taken: Candidate | null; last: Candidate | null };
  try {
    if (router !== null) {
      const ceiling = routerOutputCeiling(card);
      if (ceiling !== null && ceiling < agent.max_output_tokens) {
        const wireModel = routerWireModel(agent.model);
        throw new HouseForecastFault(
          `superbot-router's card for ${wireModel} on the router key caps an answer at ${ceiling} output tokens, under the forecast's max_output_tokens of ${agent.max_output_tokens}: ` +
            'the router would clamp the request to it (x-sbr-ignored: max_tokens) and cut and bill the answer, so nothing was sent',
          null,
          attempts,
          { upstream: 'superbot-router', fix: `raise the router key's max_tokens ceiling for ${wireModel} to at least ${agent.max_output_tokens} at superbot-router (the key is MAKEFUN_SUPERBOT_ROUTER_KEY), then run this again` },
        );
      }
    }
    sent = await sendHouseForecast({
      origin: router?.origin ?? opts.broker.origin,
      router: router !== null,
      apiKey: minted.key,
      agent,
      prompt,
      schema,
      forms,
      validate: opts.validate,
      blobs: opts.blobs,
      fetch: opts.fetch ?? globalThis.fetch,
      timeoutMs: opts.timeoutMs ?? MASQ_TIMEOUT_MS,
      now,
      sleep: opts.sleep ?? sleepFor,
      signal: opts.signal,
      keyMintedAt: mintedAt,
      attempts,
      served,
      page: opts.page,
    });
    logServed();
  } catch (err) {
    logServed();
    // Whatever was sent is retired against what it was priced at, so nothing more is spent on the key.
    const retired = await retireTrialKey(opts.broker, minted.id, houseForecastMeterMicroUsd(attempts), signalOpt).catch(() => null);
    if (err instanceof HouseForecastFault) err.retired = retired;
    throw err;
  }

  const meter = houseForecastMeterMicroUsd(attempts);
  let retired: RetiredTrialKey | null = null;
  let retireError: string | null = null;
  try {
    retired = await retireTrialKey(opts.broker, minted.id, meter, signalOpt);
  } catch (err) {
    retireError = (err instanceof Error ? err.message : String(err)).slice(0, 300);
  }
  const kept = sent.taken ?? sent.last;
  const from = attempts[(kept?.attempt ?? attempts.length) - 1];
  if (from === undefined) throw new Error('a house forecast call sends at least one request');
  const record: HouseForecastRecordT = {
    schema: HOUSE_FORECAST_RECORD_SCHEMA,
    competition: opts.slug,
    phase: opts.phase,
    task_sha256: task.sha256,
    output: task.output,
    model: agent.model,
    max_output_tokens: agent.max_output_tokens,
    reasoning_effort: agent.reasoning_effort ?? null,
    prompt_sha256: promptBlob.sha256,
    rules_sha256: sha256Hex(opts.input.rules),
    contract_sha256: sha256Hex(opts.input.contract),
    history_sha256: sha256Hex(opts.input.history),
    schema_sha256: sha256Hex(canonicalJson(schema)),
    budget: {
      requests: budget.requests,
      body_bytes: budget.bodyBytes,
      input_tokens: budget.inputTokens,
      request_micro_usd: String(budget.requestMicroUsd),
      worst_micro_usd: String(budget.worstMicroUsd),
    },
    key: { id: minted.id, label: minted.label, expires_at: isoOf(minted.expiresAt) },
    attempts,
    response_sha256: from.response_body_sha256,
    usage: sumUsage(attempts.map((t) => t.usage)),
    cost_micro_usd: meter.toString(),
    pricing_rev: pricingRev,
    masq_spend: retired === null ? null : { micro_usd: retired.spend.microUsd.toString(), settled: retired.settled, mismatch: retired.mismatch, flags: [...retired.flags] },
    retire_error: retireError,
    forecast: kept === null ? null : { attempt: kept.attempt, sha256: sha256Hex(kept.bytes), bytes: kept.bytes.byteLength, valid: kept.valid, why: kept.why },
    created_at: isoOf(now()),
  };
  return { held: null, record: HouseForecastRecord.parse(record), forecast: kept?.bytes ?? null, prompt, budget, retired };
}

// ------------------------------------------------------------------ the entry tree

/** What writeHouseEntry wrote. */
export interface HouseEntryWritten {
  dir: string;
  /** records/<task sha256>.json. */
  record: string;
  /** forecasts/<task sha256>.json; null when the record holds no forecast. */
  forecast: string | null;
  /** Whether it replaced a different record for the same task (opts.replace). */
  replaced: boolean;
}

/** Write `bytes` to `path` through a sibling temporary file and a rename, so a reader never sees half a file. */
function writeWhole(path: string, bytes: Uint8Array): void {
  const tmp = `${path}.tmp-${process.pid}`;
  writeFileSync(tmp, bytes);
  renameSync(tmp, path);
}

const sameBytes = (path: string, bytes: Uint8Array): boolean => existsSync(path) && Buffer.compare(readFileSync(path), Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength)) === 0;

/**
 * Write one instance's record and forecast into the entry tree at `dir` (the header), creating it from the template
 * or merging with what it holds: the template's files are written as they are, records/<task sha256>.json and
 * forecasts/<task sha256>.json for this instance, and every other instance's files are left alone, so a practice
 * instance and the final share one tree. The same record again is a no-op; a different record (or forecast) for
 * the same task is refused unless `replace`, which also removes a forecast the new record no longer holds. The
 * forecast must be the bytes the record names (null when it names none).
 */
export function writeHouseEntry(dir: string, record: HouseForecastRecordT, forecast: Uint8Array | null, opts: { replace?: boolean } = {}): HouseEntryWritten {
  const checked = HouseForecastRecord.parse(record);
  if ((forecast === null) !== (checked.forecast === null)) {
    throw new TypeError(checked.forecast === null ? 'the record holds no forecast, but forecast bytes were given' : `the record names forecast ${checked.forecast.sha256}, but no forecast bytes were given`);
  }
  if (forecast !== null && checked.forecast !== null && (sha256Hex(forecast) !== checked.forecast.sha256 || forecast.byteLength !== checked.forecast.bytes)) {
    throw new TypeError(`the forecast bytes hash to ${sha256Hex(forecast)} (${forecast.byteLength} bytes), not the record's ${checked.forecast.sha256} (${checked.forecast.bytes} bytes)`);
  }
  const recordBytes = houseForecastRecordBytes(checked);
  const recordPath = join(dir, 'records', `${checked.task_sha256}.json`);
  const forecastPath = join(dir, 'forecasts', `${checked.task_sha256}.json`);
  const holdsRecord = existsSync(recordPath);
  const holdsForecast = existsSync(forecastPath);
  const same = (!holdsRecord || sameBytes(recordPath, recordBytes)) && (forecast === null ? !holdsForecast : !holdsForecast || sameBytes(forecastPath, forecast));
  if (!same && opts.replace !== true) {
    throw new Error(
      `the house entry at ${dir} already holds a different ${holdsRecord && !sameBytes(recordPath, recordBytes) ? 'record' : 'forecast'} for task ${checked.task_sha256}: ` +
        'pass replace to overwrite it (an entered tree is never rewritten: enter the replaced tree as a new entry)',
    );
  }
  for (const sub of ['forecasts', 'records']) mkdirSync(join(dir, sub), { recursive: true });
  for (const file of HOUSE_ENTRY_TEMPLATE_FILES) {
    const to = join(dir, file);
    mkdirSync(dirname(to), { recursive: true });
    copyFileSync(join(HOUSE_ENTRY_TEMPLATE_DIR, file), to);
  }
  if (forecast !== null) writeWhole(forecastPath, forecast);
  else rmSync(forecastPath, { force: true });
  writeWhole(recordPath, recordBytes);
  return { dir, record: recordPath, forecast: forecast === null ? null : forecastPath, replaced: !same && (holdsRecord || holdsForecast) };
}
